The game is saved on the folder savedGames on the file saved.txt,
this is also the file read when loading a new game, so please replace it with your testing version.

The parameters are still necessary when executing even if you intend to load a game.
An example of the executing command is:
runhaskell desertExplorer.hs s 10 m 10 g 3 t 5  w 5 p 5 l 30 ll 30 x 4 y 3

For the GUI, the colors have the following meaning:

- Yellow = desert tiles
- Red = Treasure
- Blue = Oasis
- Orange = Lava
- White = Portal
- Magenta = Worm
- Violet = Player
- Black = Non-visible tiles

